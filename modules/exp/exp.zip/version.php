<?php

/**
 * @Project Mining 0.1
 * @Author Frogsis
 * @Createdate Mon, 28 Oct 2019 15:00:00 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$module_version = array(
    'name' => 'Quản lý hạn sử dụng',
    'modfuncs' => 'main, excel',
    'submenu' => 'main, excel',
    'is_sysmod' => 0,
    'virtual' => 1,
    'version' => '4.3.01',
    'date' => 'Mon, 28 Oct 2019 15:00:00 GMT',
    'author' => 'Frogsis',
    'uploads_dir' => array($module_name),
    'note' => ''
);
