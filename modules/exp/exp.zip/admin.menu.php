<?php

/**
 * @Project Mining 0.1
 * @Author Frogsis
 * @Createdate Mon, 28 Oct 2019 15:00:00 GMT
 */

if (!defined('NV_ADMIN')) die('Stop!!!');

$submenu['item'] = 'Danh sách sản phẩm';
$submenu['category'] = 'Danh sách loại hàng';
$submenu['exp'] = 'Quản lý hạn sử dụng';
$submenu['excel'] = 'Thêm bằng excel';

$allow_func = array('main', 'item', 'exp', 'excel', 'category'); 
